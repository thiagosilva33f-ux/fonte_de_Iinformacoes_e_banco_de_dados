<img width="738" height="417" alt="IMG-20260908-WA0353" src="https://github.com/user-attachments/assets/7e5c1a8e-f6fb-45d0-8fa3-7b721de6b99e" />
<img width="755" height="459" alt="IMG-20260908-WA0351" src="https://github.com/user-attachments/assets/61ee0c40-6720-4a48-9121-656f525f7ccf" />
<img width="753" height="453" alt="IMG-20260908-WA0352" src="https://github.com/user-attachments/assets/d7ce9034-767b-4879-ae5e-6a778e217c3e" />
<img width="751" height="426" alt="IMG-20260908-WA0354" src="https://github.com/user-attachments/assets/e64dd796-68a9-4304-8e20-8fe31540225f" />
<img width="745" height="424" alt="IMG-20260908-WA0350" src="https://github.com/user-attachments/assets/33595a5d-e348-4369-94fd-89f334d04305" />
